extends Node2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$credtext.text = "add the credits here!"
	$credtext.position.x = 540
	$credtext.position.y = 540

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$credtext.position.y -= 1
