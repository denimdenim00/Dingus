extends Node2D

@onready var menu = preload("res://tscn/menu.tscn")
@onready var lvl1 = preload("res://tscn/level_1.tscn")
@onready var lvl2 = preload("res://tscn/level_2.tscn")
@onready var lvl3 = preload("res://tscn/level_3.tscn")
@onready var creds = preload("res://tscn/credits.tscn")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("escape"):
		get_tree().change_scene_to_file("res://tscn/system.tscn")


func _on_menu_quit_game() -> void:
	get_tree().quit()

#SCENE TRANSITIONS
func _on_menu_start_game() -> void:
	var startgame = lvl1.instantiate()
	add_child(startgame)
	remove_child($menu)

func _on_level1_gonext() -> void:
	var nextroom = lvl2.instantiate()
	add_child(nextroom)
	remove_child($level1)
func _on_level2_gonext() -> void:
	var theboss = lvl3.instantiate()
	add_child(theboss)
	remove_child($level2)
func _on_level3_gonext() -> void:
	var ending = creds.instantiate()
	add_child(ending)
	remove_child($level3)
func _on_credits_gonext() -> void:
	var menus = menu.instantiate()
	add_child(menus)
	remove_child($credits)
