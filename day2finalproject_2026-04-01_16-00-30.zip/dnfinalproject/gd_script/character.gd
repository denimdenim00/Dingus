extends Node2D

var velocity := Vector2.ZERO
@export var acceleration: int = 1
@export var maxspeed: int = 10
var current_speed:int = 0
var directionx: int = 0
var directiony: int = 0

signal hurt
signal death
signal heal
# Called when the node enters the scene tree for the first time.


func _ready() -> void:
	pass

#MAKE MAX SPEED HIGHER AND ACCEL SLOWER?
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	
	
	if Input.is_action_pressed("up"):
		velocity = Vector2.UP
	elif Input.is_action_pressed("down"):
		velocity = Vector2.DOWN
	elif Input.is_action_pressed("left"):
		velocity = Vector2.LEFT
	elif Input.is_action_pressed("right"):
		velocity = Vector2.RIGHT
	else:
		velocity = Vector2.ZERO
	
	#directionx = Input.get_axis("down","up")
	#directiony = Input.get_axis("left","right")
	
	#velocity = Vector2.Input.get_axis("down", "up")
	#adds the use of acceleration
	if velocity:
		current_speed = move_toward(current_speed, maxspeed, acceleration)
	if velocity == Vector2.ZERO:
		current_speed = move_toward(current_speed, 0, acceleration)
	
	#actually causes movement
	position += velocity * current_speed
	
	
	
	
	#collisions
func _on_area_entered(area: Area2D) -> void:
	
	
	if area.name == "enemy1":
		emit_signal("hurt")
	if area.name == "enemy2":
		emit_signal("hurt")
	if area.name == "heart":
		emit_signal("heal")
