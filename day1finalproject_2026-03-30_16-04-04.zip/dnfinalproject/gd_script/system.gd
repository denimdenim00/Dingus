extends Node2D

@onready var menu = preload("res://tscn/menu.tscn")
@onready var lvl1 = preload("res://tscn/level_1.tscn")
@onready var lvl2 = preload("res://tscn/level_2.tscn")
@onready var lvl3 = preload("res://tscn/level_3.tscn")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("escape"):
		get_tree().change_scene_to_file("res://tscn/system.tscn")


func _on_menu_quit_game() -> void:
	get_tree().quit()


func _on_menu_start_game() -> void:
	var startgame = lvl1.instantiate()
	add_child(startgame)
	remove_child($menu)
